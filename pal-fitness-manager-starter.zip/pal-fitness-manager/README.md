# PAL FITNESS Manager — starter PWA

A mobile-first, installable web-app prototype for PAL FITNESS. It is designed to run in modern Android and Apple browsers.

## Included in this first prototype
- Dashboard with active-client, monthly collection, pending-fee and session summaries
- Add/edit client records
- Record payments
- Record attendance
- Package pricing display (Basic ₹6,000 / Standard ₹8,000 / Premium ₹10,000)
- Responsive black/charcoal/gold interface
- PWA manifest and service worker for installability/offline shell caching
- Browser localStorage for demo records

## Important limitations
This is a front-end prototype, not a production-ready business system. Data is stored only in the current browser on the current device. It does not sync between phones, has no secure login, no cloud database, no client portal, and no automatic reminders. Do not enter real client personal, medical, payment, or progress-photo information until secure authentication, server-side storage, backups, and access controls are implemented.

## Run locally
Serve this folder over HTTPS or localhost (service workers do not work from ordinary `file://` URLs). For example, use a static hosting provider or a local development server.

## Suggested next build stages
1. Connect a private GitHub repository.
2. Add Supabase authentication and database tables with Row Level Security.
3. Add client-specific workout, diet, and progress modules.
4. Add role-based owner/client access.
5. Add reminders and reporting.
6. Test on Android Chrome and iOS Safari, then deploy over HTTPS.
